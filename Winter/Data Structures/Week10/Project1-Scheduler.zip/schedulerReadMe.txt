To run this program use the Make command, 'make myProg'

System Commands:
-Type 'n' to advance system by one tick 

-Or type 'j' to enter a job into the queue 

-Or type 'p' to print the job list in the queue 

-Or type 'e' to exit the scheduler 